# SquareRepos

1.Koltin as language

2.Retrofit for networking

3.Rxjava2 for computation and network scheduling

4.Dagger2 for dependency injection

5.Unit Test: JUnit

6. Architecture Components: MVVM, room, liveData
