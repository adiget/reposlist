package com.annada.android.sample.squarerepos.models

data class Permissions(
    val admin: Boolean,
    val pull: Boolean,
    val push: Boolean
)