package com.annada.android.sample.squarerepos

class Constants {
    companion object {
        const val BASE_URL = "https://api.github.com/orgs/square/"
    }
}
